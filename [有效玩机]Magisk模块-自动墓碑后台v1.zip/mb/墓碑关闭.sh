#!/system/bin/sh

JB=/data/adb/modules/mubei/mb/mb.sh

ps -ef|grep $JB|awk '{print $2}'|while read pid;
  do
  echo "进程$pid已杀……"
  kill -9 $pid  
  done

COUNT=$(ps -ef |grep $JB |grep -v "grep" |wc -l)
#echo $COUNT
echo " "
if [ $COUNT -eq 0 ]; then
        echo -e "\e[31m没有运行……\n\e[0m"
else
        echo -e "\e[32m正在运行……\n\e[0m"
fi
  
#ps -ef |grep /data/adb/modules/mubei/mb/mb.sh
mb=/data/adb/modules/mubei/mb/mb.sh

COUNT=$(ps -ef |grep $mb |grep -v "grep" |wc -l)
#echo $COUNT
echo " "
if [ $COUNT -eq 0 ]; then
        echo -e "\e[31m没有运行……\n\e[0m"
#        /cnk_data/cnk_site/cnkang_test/web/admin/script/ugc/sticker/sticker_video_test.sh
else
        echo -e "\e[32m正在运行……\n\e[0m"
fi
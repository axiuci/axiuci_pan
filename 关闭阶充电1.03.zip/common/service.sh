sleep 1m
chmod 777 /sys/class/power_supply/battery/step_charging_enabled
while true; do
echo '0' > /sys/class/power_supply/battery/step_charging_enabled
sleep 1
done